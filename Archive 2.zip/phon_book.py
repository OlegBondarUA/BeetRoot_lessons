
import json


def add_contact():
    name = input('add name:').title()
    number = input('add number:')
    city = input('add city:').title()
    dict_number = {
        'name': name,
        'number': number,
        'city': city
    }
    with open('phone_numbers.json', 'r') as file:
        load_file = json.load(file)
        load_file.append(dict_number)
        with open('phone_numbers.json', 'w+') as file2:
            json.dump(load_file, file2, indent=4)


def serch_name():
    user_name = input('serch name?').title()
    with open('phone_numbers.json') as file:
        data1 = json.load(file)
        for item in data1:
            if user_name == 'Q':
                break
            elif item['name'] == user_name:
                print(item)


def serch_number():
    user_name = input('serch number?').title()
    with open('phone_numbers.json') as file:
        data2 = json.load(file)
        for item in data2:
            if user_name == 'Q':
                break
            elif item['number'] == user_name:
                print(item)


def serch_city():
    user_name = input('serch city?').title()
    with open('phone_numbers.json') as file:
        data3 = json.load(file)
        for item in data3:
            if user_name == 'Q':
                break
            if item['city'] == user_name:
                print(item)


def del_contact():
    user_name = input('del user:').title()
    with open('phone_numbers.json', 'r+') as file:
        data3 = json.load(file)
        for item in data3:
            if user_name == 'Q':
                break
            if item['name'] == user_name.title():
                data3.remove(item)
            else:
                print('wrong command')
                break
            with open('phone_numbers.json', 'w+') as file1:
                json.dump(data3, file1, indent=4)


def edit_contact():
    user = input('which contact do you want to change:').title()
    with open('phone_numbers.json', 'r+') as file:
        data4 = json.load(file)
        for item in data4:
            if user == 'Q':
                break
            if item['name'] == user:
                print(item)
            else:
                print('wrong command')
                break
            user2 = input('enter a new name:').title()
            item['name'] = user2
            user3 = input('enter a new number:')
            item['number'] = user3
            user4 = input('enter a new city:').title()
            item['city'] = user4
            with open('phone_numbers.json', 'w+') as file1:
                json.dump(data4, file1, indent=4)
            break

