from mymods import fibo, mymod

print(dir(fibo))
print(dir(mymod))
fibo.fib(100)
mymod.count_lines("Lesson02.py")
